/********************************************************************************
** Form generated from reading UI file 'startfrom.ui'
**
** Created by: Qt User Interface Compiler version 5.12.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STARTFROM_H
#define UI_STARTFROM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StartFrom
{
public:
    QPushButton *pushButton;

    void setupUi(QWidget *StartFrom)
    {
        if (StartFrom->objectName().isEmpty())
            StartFrom->setObjectName(QString::fromUtf8("StartFrom"));
        StartFrom->resize(750, 375);
        pushButton = new QPushButton(StartFrom);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(300, 220, 100, 50));

        retranslateUi(StartFrom);

        QMetaObject::connectSlotsByName(StartFrom);
    } // setupUi

    void retranslateUi(QWidget *StartFrom)
    {
        StartFrom->setWindowTitle(QApplication::translate("StartFrom", "Form", nullptr));
        pushButton->setText(QApplication::translate("StartFrom", "\345\274\200\345\247\213\346\270\270\346\210\217", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StartFrom: public Ui_StartFrom {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STARTFROM_H
