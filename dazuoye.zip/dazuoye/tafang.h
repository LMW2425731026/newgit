#ifndef TAFANG_H
#define TAFANG_H


class tafang
{
public:
    tafang();
};

#endif // TAFANG_H
