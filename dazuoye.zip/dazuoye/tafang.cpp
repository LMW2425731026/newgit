#include "tafang.h"

tafang::tafang()
{

}
